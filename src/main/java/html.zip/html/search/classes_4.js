var searchData=
[
  ['tuple',['Tuple',['../class_tuple.html',1,'']]]
];

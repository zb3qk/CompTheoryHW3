var searchData=
[
  ['tostring',['toString',['../class_web.html#afa2f7442238f2fc0aaa39861398d0240',1,'Web.toString(Node&lt; String &gt; n)'],['../class_web.html#adedf3de84f0f3c9350af5b54219b69ee',1,'Web.toString(delta&lt; Character &gt; d)']]]
];

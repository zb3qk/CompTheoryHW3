var searchData=
[
  ['adddelta',['addDelta',['../class_web.html#a5bccfa9eddb9815feccc8d0bd8cdb083',1,'Web']]]
];
